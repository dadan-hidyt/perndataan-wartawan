<?php $__env->startSection("content"); ?>
   <div class="container">
       <div class="page-title">
           <h3>DATA BERITA</h3>
       </div>
       <!-- tabel untuk halaman tampil berita -->
       <div class="col-md-12">
           <!-- bagian button -->
           <div class="col-md-7 mb-3">
               <a class="btn btn-sm btn-primary">Tambah Berita</a> &nbsp;
               <a href="" class="btn btn-sm btn-warning">Rekap</a>
           </div>
           <hr>
           <!-- bagian tabel -->
           <div class="table-responsive">
               <table id="tabel-berita" style="width:1700px" class="table text-center table-hover table-bordered">
                <thead>
                    <tr>
                        <th>Judul Berita</th>
                        <th>link_berita</th>
                        <th>Wartawan</th>
                        <th>tanggal_submit</th>
                        <th>Honor</th>
                        <th>Action</th>
                    </tr>
                </thead>
                   <tbody>
                   <?php if(count($data_berita) > 0): ?>
                       <?php $__currentLoopData = $data_berita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $berita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <tr>
                               <td><?php echo e($berita->judul_berita); ?></td>
                               <td><a target="__blank" title="<?php echo e($berita->link_berita); ?>" href="<?php echo e($berita->link_berita); ?>">Buka Link Berita</a></td>
                               <td><?php echo e($berita->nama); ?></td>
                               <td><?php echo e(date("d-M-Y", strtotime($berita->tanggal_submit))); ?></td>
                               <td><?php echo e($berita->honor); ?></td>
                               <td>
                                   <a class="text-secondary" href="<?php echo e(route("admin.berita.edit", $berita->id_berita)); ?>"><i class="fa fa-edit fa-2x"></i></a>
                                   &nbsp;
                                   <a class="text-danger" href="<?php echo e(route("admin.berita.delete", $berita->id_berita)); ?>"><i class="fa fa-trash fa-2x"></i></a>
                               </td>
                           </tr>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   <?php else: ?>
                    <tr>
                        <td colspan="8">Tidak ada data</td>
                    </tr>
                   <?php endif; ?>
                   </tbody>
               </table>
           </div>
       </div>
   </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jsbottom'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('jsbottom'); ?>
    <script src="<?php echo e(asset('assets/vendor/datatables/datatables.min.js')); ?>"></script>
    <script>
        // Initiate datatables in roles, tables, users page
        (function() {
            'use strict';

            $('#tabel-berita').DataTable({
                responsive: false,
                lengthChange: true,
                searching: true,
                ordering: true
            });
        })()
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inginapa\pendataan-wartawan-berita\laravel\resources\views/backend/pages/berita.blade.php ENDPATH**/ ?>