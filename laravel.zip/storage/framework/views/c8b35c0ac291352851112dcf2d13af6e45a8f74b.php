<?php $__env->startSection("title", 'Home'); ?>
<?php $__env->startSection('external-css'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('external-css'); ?>
<style>
    .card{
        border: none;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
    <div class="container">
        <div class="row">
            <div class="col col-md-4">
                <div class="card shadow-sm">
                    <div class="card-body">
                       <div class="mb-3">
                           <b>Total Wartawan</b>
                       </div>
                        <div class="mb-3">
                            <h2><?php echo e($total_wartawan); ?></h2>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-12 col-md-4">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <div class="mb-3">
                            <b>Total Berita</b>
                        </div>
                        <div class="mb-3">
                            <h2><?php echo e($total_berita); ?></h2>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-12 col-md-4">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <div class="mb-3">
                            <b>Wilayah</b>
                        </div>
                        <div class="mb-3">
                            <h2><?php echo e($wilayah); ?></h2>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("backend.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inginapa\pendataan-wartawan-berita\laravel\resources\views/backend/pages/beranda.blade.php ENDPATH**/ ?>