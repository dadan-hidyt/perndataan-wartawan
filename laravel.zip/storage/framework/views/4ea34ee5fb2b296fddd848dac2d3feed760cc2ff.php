<?php $__env->startSection('content'); ?>
    <style>
        #wartawan_filter .form-control{
           width: 100%;
            border-radius: 0;
            margin-top: 3px;
        }
    </style>
<div class="container">
    <div class="page-title">
        <h3>Wartawan</h3>
    </div>
    <hr>
    <div class="col-md-12 mb-3">
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#tambah-wartawan-modal">Tambah data</button>
    </div>
    <?php if(session()->has('messages')): ?>
        <p class="alert alert-primary"><?php echo e(session()->get('messages')); ?></p>
    <?php endif; ?>
    <!-- tabel wartawan -->
    <div class="table-responsive">
        <table style="width: 1500px" id="wartawan" class="table text-center table-bordered table-hover mt-4">
            <thead>
                <tr>
                    <th>#</th>
                    <th>KODE</th>
                    <th>Nama</th>
                    <th>TTL</th>
                    <th>Telepon</th>
                    <th>Email</th>
                    <th>Jk</th>
                    <th>Alamat</th>
                    <th>Wilayah</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            <?php
            $i = 0
            ?>
            <?php if(count($wartawan_data) > 0): ?>
                <?php $__currentLoopData = $wartawan_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $i++
                    ?>
                    <tr>
                        <td><?php echo e($i); ?></td>
                        <td><?php echo e($data->kode); ?></td>
                        <td><?php echo e($data->nama); ?></td>
                        <td><?php echo e($data->tempat_lahir); ?> , <?php echo e(date('d-m-Y', strtotime($data->tanggal_lahir))); ?></td>
                        <td><?php echo e($data->telepon); ?></td>
                        <td><?php echo e($data->email); ?></td>
                        <td><?php echo e(strtoupper($data->jk)); ?></td>
                        <td>
                            <?php if(strlen($data->alamat) > 15): ?>
                                <div title="<?php echo e($data->alamat); ?>"><?php echo e(substr($data->alamat,0,15)); ?>...</div>
                            <?php else: ?>
                                <?php echo e($data->alamat); ?>

                            <?php endif; ?>
                        </td>
                        <td><?php echo e($data->nama_wilayah); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.wartawan.edit', $data->kode)); ?>"><i class="fa fa-pen-square fa-2x text-secondary"></i></a> &nbsp;
                            <a onclick="return confirm('Apakah yakin! Ingin menghapus data ini?')" href="<?php echo e(route('admin.wartawan.delete', $data->kode)); ?>"><i class="fa fa-trash fa-2x text-danger"></i></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <tr>
                    <td colspan="8">Tidak ada data</td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
        <div class="modal fade" id="tambah-wartawan-modal" tabindex="-1" style="display: none;" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">TAMBAH DATA WARTAWAN</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body text-start">
                        <form accept-charset="utf-8" method="POST" action="<?php echo e(route('admin.wartawan.post_tambah_wartawan')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label for="nama" class="form-label">Nama</label>
                                <input required type="text" name="nama" placeholder="Ketikan nama" class="form-control">
                            </div>
                             <div class="mb-3">
                                <label for="tempatlahir" class="form-label">Tempat Lahir</label>
                                <input required type="text" name="tempat_lahir" placeholder="e.x sumedang" class="form-control">
                            </div>
                            <div class="mb-3">
                                <label for="Tanggal" class="form-label">Tanggal Lahir</label>
                                <input required type="date" name="tanggal_lahir" class="form-control">
                            </div>
                            <div class="mb-3">
                                <label for="telwa" class="form-label">Telepon/Wa</label>
                                <input required type="number" name="telepon" placeholder="e.x 62" class="form-control">
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input required type="email" name="email" placeholder="ketikan email" class="form-control">
                            </div>
                            <div class="mb-3">
                                <label for="jk">JK</label>
                                <select class="form-control" name="jk" id="jk">
                                    <option value="pria">Pria</option>
                                    <option value="wanita">Wanita</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="wilayah" class="form-label">Wilayah</label>
                                <select required class="form-control" name="kode_wilayah" id="wilayah">
                                    <option value="">--No data--</option>
                                    <?php if(!empty($wilayah)): ?>
                                        <?php $__currentLoopData = $wilayah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wlyh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($wlyh['kode_wilayah']); ?>"><?php echo e($wlyh['nama_wilayah']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label for="alamat" class="form-label">Alamat</label>
                                <textarea required name="alamat" id="" cols="20" rows="4" class="form-control"></textarea>
                            </div>
                            <div class="mb-3">
                                <button type="submit" name="submit" class="btn btn-primary">Tambah</button>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>

        <?php $__env->startSection('jsbottom'); ?>
            <?php echo \Illuminate\View\Factory::parentPlaceholder('jsbottom'); ?>
            <script src="<?php echo e(asset('assets/vendor/datatables/datatables.min.js')); ?>"></script>
            <script>
                // Initiate datatables in roles, tables, users page
                (function() {
                    'use strict';

                    $('#wartawan').DataTable({
                        responsive: false,
                        lengthChange: true,
                        searching: true,
                        ordering: true
                    });
                })()
            </script>
        <?php $__env->stopSection(); ?>


<?php echo $__env->make('backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inginapa\pendataan-wartawan-berita\laravel\resources\views/backend/pages/wartawan.blade.php ENDPATH**/ ?>