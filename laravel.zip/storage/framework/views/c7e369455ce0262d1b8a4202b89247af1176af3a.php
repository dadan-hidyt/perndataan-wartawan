<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Login</title>
    <link href="<?php echo e(asset('assets/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/auth.css')); ?>" rel="stylesheet">
    <style>
        .alert{
            text-transform: capitalize;
            border-radius: 0;
        }
    </style>
</head>
<body>
<div class="wrapper">
    <div class="auth-content">
        <div class="card">
            <div class="card-body text-center">
                <div class="mb-4">
                    <img width="100%" class="brand" src="<?php echo e(asset('assets/img.png')); ?>" alt="bootstraper logo">
                </div>
                <?php if($errors->any()): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p class="alert alert-danger"><?php echo e($err); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <?php if(session()->has('messages')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session()->get('messages')); ?>

                    </div>
                <?php endif; ?>
                <form action="<?php echo e(route('post-login')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3 text-start">
                        <label for="username" class="form-label">Username</label>
                        <input type="username" class="form-control" name="username" placeholder="Ketikan username">
                    </div>
                    <div class="mb-3 text-start">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" name="password" placeholder="ketikan password">
                    </div>

                    <button name="login" style="width: 100%" class="btn btn-primary shadow-2 mb-4">Login</button>
                </form>
            </div>
        </div>
    </div>
</div>
<script src="<?php echo e(asset('assets/vendor/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\inginapa\pendataan-wartawan-berita\laravel\resources\views/auth/login.blade.php ENDPATH**/ ?>